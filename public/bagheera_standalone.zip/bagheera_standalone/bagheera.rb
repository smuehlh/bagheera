#!/usr/local/bin/ruby

require 'rubygems'
require 'ruby-debug'
require 'json'
require 'open3'
# require 'parallel'


# load modules and classes
require './lib/helper.rb'
require './lib/progCall.rb'
require './lib/proteinFamily.rb'
require './lib/protein.rb'
require './lib/prediction.rb'
require './lib/printer.rb'
require './lib/tree.rb'

unless RUBY_VERSION.include?("1.9") then
	Helper.abort "Fatal: Wrong ruby version. Need Ruby >= 1.9.2"
end

# parse parameters
args = ARGV

if ( args.empty? || args.include?("--help") || ! args.any?{|w| w =~ /^--query=/} ) && ! args.include?("--more_params") then
	# display help
	puts "Bagheera is a tool for codon usage prediciton in yeast"
	puts "Contact: Stefanie Muehlhausen (stmu[at]nmr.mpibpc.mpg.de), Martin Kollmar (mako[at]nmr.mpibpc.mpg.de)"
	puts ""
	puts "Usage: bagheera.rb [params] --query=path_to_file --config=path_to_file"
	puts ""
	puts "--query=<path_to_file>"
	puts "\t Path to fasta-formatted input file"
	puts ""
	puts "--config=<path_to_file>"
	puts "\t Path to configuration file of this format:"
	puts "blast_path=<path to blast executable>"
	puts "fastacmd_path=<path to fastacmd executable>"
	puts "formatdb_path=<path to formatdb executable>"
	puts "augustus_path=<path to augustus executable>"
	puts "augustus_config_path=<path to config directory of augustus>"
	puts "augustus_species=<species model. check augustus documentation for valid options>"
	puts "mafft_path=<path to mafft executable>"
	puts "pairalign_path=<path to pair_align executable>"
	puts "gblocks_path=<path to gblocks executable>"
	puts "fasttree_path=<path to fasttree executable>"
	puts ""
	puts ""
	puts "Parameters:"
	puts "--project_name=<string> [default: none]"
	puts "\t Creates a subdir <project_name> in ./pred/"
	puts ""
	puts "--n_blasthits=<integer> [default: 1]"
	puts "\t Use <integer> best blast hits for gene prediction"
	puts ""
	puts "--align_method=[mafft|nw|gotoh|sw|lcs] [default: mafft]"
	puts "\t Specifiy alignment method. Recommended: mafft"
	puts ""
	puts "--align_config=[tttt|ffff] [default: none]"
	puts "\t Specifiy alignment configuration (end gap free [tttt] or standard global alignment [ffff])"
	puts "\t Only legal with align_method=[nw|gotoh|sw|lcs]"
	puts ""
	puts "--tree=[5|10]"
	puts "\t Calculate a phylogenetic tree of query sequence and the reference species."
	puts "\t Specifiy number of motor proteins to concatenate."
	puts "\t Only legal with align_method=mafft"
	puts ""
	puts ""
	# puts "Type \'bagheera.rb --more_params\' to see a list of parameters to configure external programs"
	# puts ""
	exit
end 

# initialize parameters with default values
$tmp_dir = "./tmp/"
$out_dir = "./pred/"
$out_alignment_dir = File.join($out_dir, "alignments/")
out_file = "prediction.txt"
in_file = nil
genome_db = nil
n_blasthits = 1

is_tree = false
n_prot_tree = 0

# set user-defined values and check if they are valid
print "Parse parameters "
while args.count > 0 do
	if ! args[0] =~ /=/ && args[0] != "--more_params" then
		Helper.warn "Fatal: Unknown option #{args[0]}"
		Helper.abort "Specifiy options in <param=value> form"
	else
		para, val = args[0].split("=")
		para.slice!("--")
		if val.nil? && para != "more_params" then
			Helper.warn "Fatal: Unknown option #{args[0]}"
			Helper.abort "Specifiy options in <param=value> form"
		end

		# parse parameters
		case para
		when "query"
			in_file = val
			args.delete_at(0)
			if ! File.exist?(in_file) then
				Helper.abort "Fatal: Query file #{in_file} does not exit"
			end
		when "config"
			# configure pathes to external programs
			ProgCall.config(val)
			args.delete_at(0)
		when "project_name"
			$out_dir += File.basename val # remove all "/" or "\", if any
			$out_dir += "/"
			$out_alignment_dir = File.join $out_dir, "alignments/"
			args.delete_at(0)
		when "n_blasthits" 
			n_hits = val.to_i
			if n_hits < 1 || n_hits > 10 then
				Helper.warn "Invalid value/range for n_blasthits #{val}"
				Helper.warn "Use default value: 1"
			else
				n_blasthits = n_hits
			end
			args.delete_at(0)
		when "tree"
			is_tree = true
			n_prot_tree = val.to_i
			if ! (n_prot_tree == 5 || n_prot_tree == 10) then
				Helper.warn "Invalid value for tree #{val}"
				Helper.warn "Use default value: 5"
				n_prot_tree = 5
			end
			args.delete_at(0)
		when "align_method"
			if ! ["mafft", "nw", "gotoh", "sw", "lcs"].include?(val) then
				Helper.warn "Invalid alignment method #{val}"
				Helper.warn "Use default method: mafft"
				val = "mafft"		
			end
			Prediction.class_variable_set(:@@align_method, val)
			args.delete_at(0)
		when "align_config"
			Prediction.align_config = val
			if ! ["tttt", "ffff"].include?(val) then
				Helper.warn "Invalid alignment configuration #{val}"
				Helper.warn "Use default: tttt"
				val = "tttt"
			end
			Prediction.class_variable_set(:@@align_config, val)
			args.delete_at(0)

		# # display list of additinal parameters			
		# when "more_params"
		# 		puts "TODO"
		else 
			Helper.abort "Unkown option #{args[0]}"
		end
	end 
end
print "... done.\n"
### check if options are legal

## cross-dependent options
# use align_config only with alignment methods other than mafft
if Prediction.class_variable_get(:@@align_method) == "mafft" then
	if Prediction.class_variable_get(:@@align_config) != "" then
		Helper.warn "Warning: Illegal use of \'align_config\'. Ignore setting #{Prediction.class_variable_get(:@@align_config)}
		with \'align_method\' mafft"
		Prediction.class_variable_set(:@@align_config, "")
	end
else
	if Prediction.class_variable_get(:@@align_config) == "" then
		Helper.warn "Warning: Illegal use of \'align_config\'. Missing setting #{Prediction.class_variable_get(:@@align_config)}
		wih \'align_method\' #{Prediction.class_variable_get(:@@align_method)}"
		Prediction.class_variable_set(:@@align_config, "tttt")
	end
end

# use tree only with aligment method mafft
if is_tree && Prediction.class_variable_get(:@@align_method) != "mafft" then
	Helper.warn "Warning: Illegal use of \'tree\' with align_method #{Prediction.class_variable_get(:@@align_method)}. Ignore setting."
	Helper.warn ""
	is_tree = false
end

### main method

# initialize part II
Helper.mkdir_or_die($out_dir)
Helper.mkdir_or_die($out_alignment_dir)
fh_results = File.new($out_dir + out_file, "w")
ProgCall.genome_db = $tmp_dir + "/" + File.basename(in_file, ".*") + "_db"
stats = {:n_prots => 0, :conserved_pos => 0, :pred_cugs => 0} # save overall statistics

# load reference data
ref_data = Helper.load_ref_data

# setup database
ProgCall.create_blast_db(in_file)

# predict gene for every reference protein
# Parallel.each( ref_data.keys.sort_by {|key| key.to_s.naturalized}, :in_threads => 10 ) do |prot|
# 	# , :in_processes => 0 
ref_data.keys.sort_by { |key| key.to_s.naturalized }.each do |prot|
	all_prot_data = ref_data[prot]
	prot_obj = Protein.new(prot, all_prot_data)

	puts "Predicting CUG usage in #{prot}"

	(1..n_blasthits).each do |this_hit|

		pred_obj = Prediction.new(prot_obj, this_hit)
		puts "Using BLAST hit #{pred_obj.this_hit_nr}"
		pred_obj.predict

		# save stats
		Helper.calc_stats(stats, pred_obj)

		if ! pred_obj.err_msg.empty? then
			puts pred_obj.err_msg
		elsif pred_obj.pred_cug

			# append results to file
			Printer.print_str(fh_results, "#{prot} (#{this_hit})")
			Printer.print_pred(fh_results, pred_obj.pred_cug)
			Printer.print_str(fh_results, "Predicted sequence (CUG codon positions indicated by '*')")
			Printer.print_seq(fh_results, pred_obj.pred_cug[:pred_prot], pred_obj.pred_cug[:ctg_pos])
			Printer.print_str(fh_results, "\n\n")
		end

	end

end

fh_results.close

# output overall statistics
puts "\nSummary"
puts "Predicted proteins:\t#{stats[:n_prots]}"
puts "Predicted CTG positions:\t#{stats[:pred_cugs]}"
puts "Conserved CTG positions:\t#{stats[:conserved_pos]}"

if is_tree then
	puts "Calculate phylogenetic tree"
	tree_obj = Tree.new(n_prot_tree)
	tree_obj.calc_tree
end

# puts "Finished!"