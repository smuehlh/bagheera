module Helper
	extend self


	# general error handling methods
	def abort(msg="Fatal: An error occured")
		$stderr.puts msg
		exit 1
	end

	def warn(msg)
		$stderr.puts msg
	end

	def worked_or_throw_error(is_success, msg)
		if ! is_success then
			throw :problem, msg
		end
		is_success
	end

	# general file handling methods
	def file_exist_or_die(path)
		if ! FileTest.file?(path) then
			abort "Fatal: File #{path} does not exist."
		end
	end

	def dir_exist_or_die(path)
		if ! FileTest.directory?(path) then
			abort "Fatal: Directory #{path} does not exist."
		end
	end

	def mkdir_or_die(path)
		if ! FileTest.directory?(path) then
			begin
				Dir.mkdir(path)
			rescue
				abort "Fatal: Cannot create directory #{path}"
			end
		end
	end

	def worked_or_die(is_success, msg)
		if ! is_success then
			abort "Fatal: #{msg}"
		end
	end

	def worked_or_errmsg(is_success, msg)
		if ! is_success then
			Prediction.err_msg = msg
		end
		# $stdout.puts msg
		is_success
	end

	# 'specific' file handling for this project
	def load_ref_data
		path = "./data/alignment_gene_struct.json"
		if ! FileTest.file?(path) then
			abort "Fatal: Cannot load reference data from #{path}."
		end
		return JSON.load(File.read(path))
	end

	def get_tmp_file
		$tmp_dir + rand(1000000).to_s + ".fasta"
	end

	# progress-reporting methods
	def done
		print "... done \n"
	end

	def calc_stats(stats, pred_obj)
		# update predicted protein count
		if pred_obj.pred_seq then
			stats[:n_prots] += 1
		end

		# update predicted CUG codon count
		if pred_obj.pred_cug then
			# all predicted CUG codons
			stats[:pred_cugs] += pred_obj.pred_cug[:ctg_pos].size

			# conserved CUG codons
			stats[:conserved_pos] += pred_obj.pred_cug[:ref_ctg].keys.size 
		end
	end

	module Sequence
		extend self
		require 'yaml'

		def fasta2str(fasta)
			headers = []
			seqs = []
			# get every record: everything between two ">"
			fasta.scan(/^>([^>]*)/m).flatten.each do |rec|
				rec.chomp!
				nl = rec.index("\n") # first match: separating header from seq
				header = rec[0..nl-1]
				seq = rec[nl+1..-1]
				seq.gsub!(/\r?\n/,'') # removing all remaining \n from seq 
				headers.push(header)
				seqs.push(seq)
			end
			return headers, seqs
		end


		def str2fasta(header, seq, no_split=false)
			fasta = header.include?(">") ? header << "\n" : ">" << header << "\n"
			if no_split then
				fasta += seq
			else
				fasta += seq.scan(/.{1,80}/).join("\n")
			end
			return fasta
		end

		def sequence_pos2alignment_pos(spos, aseq)
			pats = []
			aseq.gsub("-", "")[0..spos].split("").each {|chr| pats << ("-*" + chr)}
			pat = Regexp.new(pats.join)
			pat.match(aseq)[0].length - 1
		end

		def alignment_pos2sequence_pos(apos, aseq)
			aseq[0..apos].gsub("-", "").length - 1
		end

		def extract_translation(gene)
			g = Gene.new(YAML.load(gene))
			g.translation
		end

		def extract_cdna(gene)
			g = Gene.new(YAML.load(gene))
			g.cdna.upcase
		end

		def split_cdna_into_codons(gene, pos)
			dna_seq = extract_cdna(gene) # dna sequence
			codons = dna_seq.scan(/.{1,3}/)
			return codons[pos]
		end
	end

	class Gene
		require 'yaml'

		def initialize(blat_data)
			@blat_data = blat_data
			exon_number = 0
			@blat_data.each_with_index do |contig, contig_index|
			contig["number"] = contig_index.to_i + 1
			contig["matchings"].each do |matching|
			if matching["type"] == "exon" then
				exon_number += 1
				matching["number"] = exon_number.to_i
			elsif matching["type"] == "intron" ||  matching["type"] == "intron?" then
				matching["number"] = exon_number.to_i
			end
				matching["contig"] = contig_index.to_i + 1
			end
		end

		def contigs
			@blat_data
		end
		def matchings
			contigs.collect do |c| c["matchings"] end.flatten
		end
		def exons
			matchings.select do |m| m["type"] == "exon" || m["type"] == "exon_alternative" end
		end

		def cdna
			exons.select{|e| e["type"] != "exon_alternative" || e["alternative_type"] == "mutual_exclusive" || e["alternative_type"] == "duplicated_exon"}.collect do |e| e["seq"] end.join('').upcase
		end
		
		def translation
			exons.select{|ex| ex["type"] == "exon"}.collect do |m| m["translation"] end.join('')
		end

	end
    
end

end

class Array
    def sum
        self.inject{|sum,x| sum + x }
    end
	def find_each_index find
		found, index, q = -1, -1, []
		while found
			found = self[index+1..-1].index(find)
			if found
				index = index + found + 1
				q << index
			end
		end
		q
	end
end

class String
	def naturalized
		scan(/[^\d\.]+|[\d\.]+/).collect { |f| f.match(/\d+(\.\d+)?/) ? f.to_f : f }
	end
end


	# # this method is designed to be useful for Kollmar Group only
	# def update_ref
	# 	all_data, errors = load_ref_data
	# 	if errors.empty? then
	# 		use_list = ["Actin", "Dynactin", "Myosin heavy chain", "Wiskott Aldrich", "Coronin", "Capping"]
	# 		regex = Regexp.union(*use_list)
	# 		part_data = {}
	# 		all_data.each do |prot, prot_data|
	# 			if regex.match(prot) then
	# 				puts "#{prot}"
	# 				part_data[prot] = prot_data
	# 			end
	# 		end
	# 		fh = File.new("data/alignment_gene_struct.json", "w")
	# 		fh.puts JSON.dump(part_data)
	# 		fh.close
	# 	end
	# end