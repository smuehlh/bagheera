module Printer
	extend self

	def print_pred(fh, pred_data)

		# print amino acid distribution
		if pred_data[:ref_chem].any? then

			print_aa_table(fh, pred_data[:ref_chem])

			fh.puts "Number of sequences in reference alignment: #{pred_data[:ref_seq_num]}"
		else
			fh.puts "No CTG position aligned with discriminative sites of reference data"
		end

		# print ctg usage
		if pred_data[:ref_ctg].any? then

			print_ctg_table(fh, pred_data[:ref_ctg])
		else
			fh.puts "No CTG codons in reference data at same positions"
		end

		# print suggested translation
		if pred_data[:ref_ctg].any? || pred_data[:ref_chem].any? then
			fh.puts suggested_transl(pred_data[:ref_ctg], pred_data[:ref_chem])
		end

	end

	def print_str(fh, str)
		fh.puts str
	end

	def print_seq(fh, seq, pos)
		# prepare string containing '*' at indicate a cug position
		str = " " * seq.size
		pos.each do |pos|
			str[pos] = "*"
		end

		# split strings for better readablilty
		seq_parts = seq.scan(/.{1,80}/)
		str_parts = str.scan(/.{1,80}/)

		# merge them
		merged = str_parts.zip(seq_parts).flatten.compact

		fh.puts merged.join("\n")
	end

	def print_aa_table(fh, refchem_data)
		fh.puts "CTG position\t Distribution of amino acids in reference data\t Number of amino acids"
		refchem_data.each do |pos, data|
			print_this = []

			# add data
			print_this << ruby2human_counting(pos).to_s
			print_this << format_aa_stats(data[:aa_comp])
			print_this << data[:aa_num].to_s

			if ! data[:is_significant] then
				print_this[0] = "[ " << print_this.first
				print_this[-1] = print_this.last << " ]"
			end

			fh.puts print_this.join("\t")
		end
		fh.puts "[] -- position is not significant"
		fh.puts "\n"
	end

	def print_ctg_table(fh, refctg_data)
		fh.puts "CTG position \t CTG usage in reference data\tNumber of CTG codons"
		refctg_data.each do |pos, data|
			print_this = []
			print_this << ruby2human_counting(pos).to_s
			print_this << format_ctg_stats(data[:ctg_usage])
			print_this << data[:ctg_num]

			fh.puts print_this.join("\t")
		end
	end

	def format_aa_stats(stats, is_reject_low=true)
		res = []
		has_rejected = false 
		stats.sort_by {|k, v|v}.reverse.each do |aa, freq|
			if freq >= 0.05 && is_reject_low then
				res << (aa + ": " + (freq*100).round.to_s + "%")
			elsif freq < 0.05 && is_reject_low 
				has_rejected = true
			end
		end
		res << "Others: < 5%" if has_rejected
		# check if any freq is < 0.05 than add "Others: , 5%"
		return res.join(", ")
	end

	def format_ctg_stats(data)
		str = ""
		if data.has_key?("S") then
			str = "S: #{data["S"].to_s}"
		end
		if data.has_key?("S") then
			str += "L: #{data["L"].to_s}"
		end

		return str
	end

	def ruby2human_counting(num)
		if num.kind_of?(Array) then
			numplus = num.collect do |n|
				next if n.blank? || n.nil?
				n += 1
			end
			return numplus
		elsif num.kind_of?(Fixnum) 
			return num + 1
		end
	end

	def suggested_transl(ref_chem, ref_ctg, simple_output=false)
		res = []

		# counts for aa distribution in reference data
		pos_ser = ref_chem.collect{|k,v| k if v[:transl] == "S"}
		pos_leu = ref_chem.collect{|k,v| k if v[:transl] == "L"}
		# add counts for ctg usage in reference data
		pos_ser = pos_ser | ref_ctg.collect{|k,v| k if v[:transl] == "S"} # set union
		pos_leu = pos_leu | ref_ctg.collect{|k,v| k if v[:transl] == "L"} # set union

		pos_ser.compact!
		pos_leu.compact!

		alt_usage = (pos_ser - pos_leu).size # set difference
		std_usage = (pos_leu - pos_ser).size # set difference
		strange = (pos_ser & pos_leu).size # set intersect

		# only add to results if values are not zero
		if alt_usage > 0 then
			res << "#{alt_usage} CTG position(s) suggest alternative codon usage."
		end
		if std_usage > 0 then
			res << "#{std_usage} CTG position(s) suggest standard codon usage."
		end
		if strange > 0 then
			res << "#{strange} CTG position(s) leads to contrary results." 
				# " suggest contrary codon usage based on distribution of amino acids and CTG usage in reference data."
		end

		if simple_output then
			return [alt_usage, std_usage]
		else
			return res.join("\n")
		end
	end
end