module ProgCall
	extend self

	attr_accessor :augustus_path, :augustus_config_path, :augustus_species, :blast_path, :fastacmd_path, :formatdb_path,
		:mafft_path, :pairalign_path, :blosum62_path, :gblocks_path, :fasttree_path, :genome_db

	@augustus_path = ""
	@augustus_config_path = ""
	@augustus_species = "candida_albicans"


	@blast_path = ""
	@fastacmd_path = ""
	@formatdb_path = ""

	@mafft_path = ""
	@pairalign_path = ""
	@blosum62_path = ""

	@gblocks_path = ""
	@fasttree_path = ""

	@genome_db = ""

	def create_blast_db(f_in)
		# -i [INPUT: GENOME FILE] -p [PROTEIN] FALSE -n [DB NAME] -o [CREATE INDEX OVER SEQID] TRUE
		is_success = system(@formatdb_path, "-i", f_in, "-p", "F", "-n", @genome_db, "-o", "T")
		# no output needed, so system is sufficient
		Helper.worked_or_die(is_success, "Cannot create BLAST database from genome data.")
	end

	def blast(f_out, f_ref)
		# -p [PROGRAM] protein query against nt-db -d [DATABASE] 
		# -i [FILE] -m8 [OUTPUT FORMAT] -F [FILTERING] -s [SMITH-WATERMAN ALIGNMENT] T 
		stdin, stdout_err, wait_thr = Open3.popen2e(@blast_path, 
			"-p", "tblastn", "-d", @genome_db, "-i", f_ref, "-m8", "-F", "F", "-s", "T")
		stdin.close
		output = stdout_err.read
		stdout_err.close

		if ! wait_thr.value.success? || output.include?("ERROR") || output.empty? then
			return false
		end

		File.open(f_out, 'w') {|f| f.write(output)}
		return true 
	end

	def fastacmd(f_out, seq_id, start, stop, strand)
		# -d [DB] -p [PROTEIN] false -s [SEARCH STRING] -L [START,STOP]
		# add 1000 nucleotides to start/stop 
		stdin, stdout_err, wait_thr = Open3.popen2e(@fastacmd_path, "-d", @genome_db, "-p", "F", "-s", seq_id, 
		"-L", "#{start},#{stop}", "-S", strand.to_s, "-o", f_out)
		stdin.close
		output = stdout_err.read
		stdout_err.close
		if ! wait_thr.value.success? then
			return false
		end
		return true,output
	end

	def augustus(f_out, f_in, prfl_file)
		# --species [REFERENCE SPEC] QUERY --genemodel=exactlyone [predict exactly one complete gene] --codingseq=on [output also coding sequence]
		# --strand=forward [use only forward strand for gene prediction; this works as fastacmd always translates into forward strand]
		# --proteinprofile profilefile [use protein profile about alignment as foundation for gene prediciton]
		# redirection: add stderr to stdout (screen)
		stdin, stdout_err, wait_thr = Open3.popen2e(@augustus_path, "--AUGUSTUS_CONFIG_PATH=#{@augustus_config_path}", 
			"--species=#{@augustus_species}", "--genemodel=exactlyone", "--strand=forward", "--codingseq=on", 
			"--proteinprofile=#{prfl_file}", f_in)
		stdin.close
		output = stdout_err.read
		stdout_err.close
		if (! wait_thr.value.success?) || output.include?("ERROR") || ! output.include?("coding sequence") then
			return false
		end
		File.open(f_out, 'w') {|f| f.write(output)}
		return true
	end

	def mafft(f_out, f_in_pred, f_in_ref)
		# --addfragments: add non-full length sequence to existing MSA
		# --amino: input is protein
		# --anysymbol: replace unusal symbols by "X"
		# --quiet: output only alignment
		stdin, stdout_err, wait_thr = Open3.popen2e(@mafft_path, "--addfragments", f_in_pred, "--amino", "--anysymbol", "--quiet", f_in_ref)
		stdin.close
		output = stdout_err.read
		stdout_err.close
		if ! wait_thr.value.success? then
			return false, ""
		end
		File.open(f_out, 'w') {|f| f.write(output)}
		return true
	end

	def pairalign(f_out, f_in, conf, meth)
		# -c tttt: initialize first row & column with zeros, search last row & column for maximum
		# 	=> end gap free alignment
		# --matrx matrix file
		# implicit options: gap open penalty: -11, gap extension penalty: -1
		# 					protein sequences
		# don't use system, as pair_align is quite verbose and has an easy parsable success-output
		stdin, stdout_err, wait_thr = Open3.popen2e(@pairalign_path, "--seq", f_in, "--matrix", @blosum62_path, 
			"--config", conf, "--method", meth, "--outfile", f_out)
		stdin.close
		output = stdout_err.read
		stdout_err.close
		if ! wait_thr.value.success? || ! output.include?("Alignment score") then
			return false
		end
		return true
	end

	def gblocks(f_in)
		stdout = IO.popen([@gblocks_path, f_in, "-b5=h", "-p=n"])
		output = stdout.read
		stdout.close
		# return value is always false, so parse output to find out if it was successful
		if output.include?("selected block(s)") then
			return true
		else
			return false
		end
	end

	def fasttree(f_in, f_out)
		is_success = system(@fasttree_path, "-out", f_out, f_in)
	end

	def config(configfile)
		Helper.file_exist_or_die(configfile)
		IO.foreach(configfile) do |line|
			line.chomp!
			prog,path = line.split(/\=/)
			prog.strip!
			path.strip!
			case prog 
			when "blast_path"
				Helper.file_exist_or_die(path)
				@blast_path = path
			when "fastacmd_path"
				Helper.file_exist_or_die(path)
				@fastacmd_path = path
			when "formatdb_path"
				Helper.file_exist_or_die(path)
				@formatdb_path = path
			when "augustus_path"
				Helper.file_exist_or_die(path)
				@augustus_path = path
			when "augustus_config_path"
				Helper.dir_exist_or_die(path)
				@augustus_config_path = path
			when "augustus_species"
				@augustus_species = path
			when "mafft_path"
				Helper.file_exist_or_die(path)
				@mafft_path = path
			when "pairalign_path"
				Helper.file_exist_or_die(path)
				@pairalign_path = path
			when "gblocks_path"
				Helper.file_exist_or_die(path)
				@gblocks_path = path
			when "fasttree_path"
				Helper.file_exist_or_die(path)
				@fasttree_path = path
			else
				Helper.abort "Unknown option #{prog} in config file #{configfile}"			
			end
		end
	end
end