class ProteinFamily
	attr_reader :prot, :prot_basename, 
		:ref_alignment_file, :ref_alignment, :ref_genes, :ref_prfl_file

	def initialize(prot, data)
		@prot = prot 
		@prot_basename = get_file_save_name 
		@ref_prfl_file = get_fname("prfl")
		@ref_alignment_file = get_fname("refalignment")
		@ref_alignment, @ref_genes = get_refdata(data)
	end

	def get_file_save_name
		@prot.gsub(" ", "-").downcase
	end

	def get_refdata(data)
		seqs = Hash[*data["alignment"].split("\n")]
		seqs.keys.each {|k| seqs[ k.sub(">", "") ] = seqs.delete(k)}
		genes = data["genes"]
		return seqs, genes
	end

	def get_fname(type)
		file = ""
		case type
		when "prfl"
			file = "./data/" + @prot_basename + ".prfl"
		when "refalignment"
			file = "./data/" + @prot_basename + ".fasta"
		end
		Helper.file_exist_or_die(file)
		return file
	end

end